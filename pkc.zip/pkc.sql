-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Mar 2022 pada 16.30
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pkc`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_jabatan`
--

CREATE TABLE `m_jabatan` (
  `KD_JABATAN` varchar(255) NOT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `RANK` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `m_jabatan`
--

INSERT INTO `m_jabatan` (`KD_JABATAN`, `DESC`, `RANK`) VALUES
('50002161', 'General Manager', 1),
('50002162', 'Staf Utama I', 2),
('50002163', 'Staf Utama II', 3),
('50002164', 'Manager', 4),
('50002165', 'Staf Madya I', 5),
('50002166', 'Staf Madya II', 6),
('50002167', 'Superintendent', 7),
('50002168', 'Staf Muda I', 9),
('50002169', 'Staf Muda II', 10),
('50002170', 'Supervisor', 11),
('50002171', 'Staf Pratama I', 12),
('50002173', 'Staf Pratama II', 13),
('50002175', 'Staf Pratama III', 14),
('50002176', 'Pelaksana Utama', 15),
('50002177', 'Pelaksana Madya', 16),
('50002178', 'Pelaksana Muda', 17),
('50002179', 'Pelaksana Pratama', 18),
('50004426', 'Ass. Superintendent', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_karyawan`
--

CREATE TABLE `m_karyawan` (
  `NO_BADGE` int(11) NOT NULL,
  `NAMA` varchar(255) DEFAULT NULL,
  `SALUTATION` varchar(255) DEFAULT NULL,
  `TEMPAT_LAHIR` varchar(255) DEFAULT NULL,
  `DATE_OF_BIRTH` date DEFAULT NULL,
  `JK` varchar(255) DEFAULT 'Male',
  `STATUS_KAWIN` varchar(255) DEFAULT 'Nikah',
  `UNIT_KERJA` varchar(255) DEFAULT NULL,
  `KD_JABATAN` varchar(255) DEFAULT NULL,
  `STATUS` varchar(30) DEFAULT 'aktif'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `m_karyawan`
--

INSERT INTO `m_karyawan` (`NO_BADGE`, `NAMA`, `SALUTATION`, `TEMPAT_LAHIR`, `DATE_OF_BIRTH`, `JK`, `STATUS_KAWIN`, `UNIT_KERJA`, `KD_JABATAN`, `STATUS`) VALUES
(3022111, 'Ronny Sarkasih', 'Bapak', 'Bandung', '1980-01-08', 'Male', 'Nikah', 'Bagian Rendal Produksi NPK 2', '50002167', 'aktif'),
(3022112, 'Aditya Gunawan', 'Bapak', 'Karawang', '1992-01-10', 'Male', 'Nikah', 'Bagian Produksi K1 A', '50002161', 'aktif'),
(3022113, 'Aditya Firman', 'Bapak', 'Bekasi', '1972-02-20', 'Male', 'Nikah', 'Bagian Teknologi Informasi', '50002166', 'aktif'),
(3022114, 'Dendi Nugraha', 'Bapak', 'Purwakarta', '1989-03-01', 'Male', 'Nikah', 'Bagian Akuntansi', '50002163', 'aktif'),
(3022115, 'Reksi Firmansyah', 'Bapak', 'Purwokerto', '1980-08-17', 'Male', 'Nikah', 'Bagian Keuangan', '50002164', 'aktif'),
(3022116, 'Dinda Ainun', 'Ibu', 'Karawang', '1984-09-01', 'Female', 'Nikah', 'Bagian Keuangan', '50002163', 'aktif'),
(3022117, 'Putri Nurul ', 'ibu', 'Karawang', '1993-01-02', 'Female', 'Nikah', 'Bagian Keuangan', '50002171', 'aktif'),
(3022118, 'Ferdiansyah', 'Bapak', 'Purwakarta', '1992-02-01', 'Male', 'Nikah', 'Bagian Akuntansi', '50002170', 'aktif'),
(3022119, 'Siti Syarifah', 'Ibu', 'Karawang', '1990-10-02', 'Female', 'Nikah', 'Bagian K3', '50002164', 'aktif'),
(3022120, 'Saipul Jamil', 'Bapak', 'Bekasi', '1993-11-01', 'Male', 'Nikah', 'Bagian Teknologi Informasi', '50002164', 'aktif'),
(3022121, 'Aliando Rizki', 'Bapak', 'Karawang', '1997-09-07', 'Male', 'Nikah', 'Bagian Teknologi Informasi', '50002171', 'aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_keluarga`
--

CREATE TABLE `m_keluarga` (
  `FAMILY_ID` int(11) NOT NULL,
  `NO_BADGE` varchar(255) DEFAULT NULL,
  `RELATIVE_ID` varchar(255) DEFAULT NULL,
  `RELATIVE` varchar(255) DEFAULT NULL,
  `NAMA` varchar(255) DEFAULT NULL,
  `GENDER` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `m_keluarga`
--

INSERT INTO `m_keluarga` (`FAMILY_ID`, `NO_BADGE`, `RELATIVE_ID`, `RELATIVE`, `NAMA`, `GENDER`) VALUES
(1, '3022111', '1', 'Pasangan', 'Siti Nurul', 'Female'),
(2, '3022111', '2', 'Anak', 'Dendi Roni', 'Male'),
(3, '3022111', '2', 'Anak', 'Rian', 'Male'),
(4, '3022112', '1', 'Pasangan', 'Fitri Nur', 'Female'),
(5, '3022113', '1', 'Pasangan', 'Nurul Suci', 'Female'),
(6, '3022113', '2', 'Anak', 'Roni Firmansyah', 'Male'),
(7, '3022113', '2', 'Anak', 'Jihan Nurul', 'Female'),
(8, '3022113', '2', 'Anak', 'Ferdian', 'Male'),
(9, '3022114', '1', 'Pasangan', 'Ayu Azhari', 'Female'),
(10, '3022114', '2', 'Anak', 'Jihan Azhari', 'Female'),
(11, '3022115', '1', 'Pasangan', 'Nita Harlita', 'Female'),
(12, '3022116', '1', 'Pasangan', 'M. Rizki Putra', 'Male'),
(13, '3022116', '2', 'Anak', 'Asep Nur Rizki', 'Male'),
(14, '3022117', '1', 'Pasangan', 'Maman Abdul', 'Male'),
(15, '3022117', '2', 'Anak', 'Rizki Nur Maman', 'Male'),
(16, '3022118', '1', 'Pasangan', 'Fitria Nur Apipah', 'Female'),
(17, '3022119', '1', 'Pasangan', 'Dendi Surendi', 'Male'),
(18, '3022119', '2', 'Anak', 'Priska Surendi', 'Female'),
(19, '3022120', '1', 'Pasangan', 'Ayu Ting Ting', 'Female'),
(20, '3022120', '2', 'Anak', 'Nazar', 'Male'),
(21, '3022121', '1', 'Pasangan', 'Prily Nur Apriani', 'Female');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `m_jabatan`
--
ALTER TABLE `m_jabatan`
  ADD PRIMARY KEY (`KD_JABATAN`) USING BTREE,
  ADD KEY `PK1` (`KD_JABATAN`);

--
-- Indeks untuk tabel `m_karyawan`
--
ALTER TABLE `m_karyawan`
  ADD PRIMARY KEY (`NO_BADGE`),
  ADD KEY `no_badge` (`NO_BADGE`);

--
-- Indeks untuk tabel `m_keluarga`
--
ALTER TABLE `m_keluarga`
  ADD PRIMARY KEY (`FAMILY_ID`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `m_karyawan`
--
ALTER TABLE `m_karyawan`
  MODIFY `NO_BADGE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3022122;

--
-- AUTO_INCREMENT untuk tabel `m_keluarga`
--
ALTER TABLE `m_keluarga`
  MODIFY `FAMILY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
